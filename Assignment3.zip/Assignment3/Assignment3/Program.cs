﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data.SqlClient;
namespace Assignment3
{
    public class SimpleStringComparer : IComparer
    {
        int IComparer.Compare(object x, object y)
        {
            string cmpstr = (string)x;
            return cmpstr.CompareTo((string)y);
        }
    }

    public class MyArrayList : ArrayList
    {
        public static void Main()
        {
            string fname = "", id = "";
            string filename = @"C:\Users\GEEKS4LEARNING\Desktop\Assignment2.txt";
            //=================- Creates and initializes a new ArrayList. -================

            MyArrayList list = new MyArrayList();
           
            
                while (fname != "Zzz")
                {
                    Console.Write("Enter your name: ");
                    fname = Console.ReadLine();
                    Console.Write("Input id number: ");
                    id = Console.ReadLine();
                    passData(fname, id);
                }
           
            try
            {
                //=============================- create and write to a file -===========================

                using (TextWriter writer = File.CreateText(filename))
                {
                    Console.WriteLine("file created!!");
                    foreach (string a in list)
                    {
                        writer.WriteLine(a);
                    }
                }

            }
            catch (Exception)
            {
                Console.WriteLine("the was an error....");
            }


            Console.WriteLine("press any key to continue...");
            Console.ReadKey();

            //========================================- read from file -=============================

            if (System.IO.File.Exists(filename))
            {
                using (System.IO.StreamReader sr = System.IO.File.OpenText(filename))
                {
                    String input;
                    while ((input = sr.ReadLine()) != null)
                    {
                        Console.WriteLine(input);
                    }
                    Console.WriteLine("=================================================================");
                }
            }
            else
            {
                Console.WriteLine("File not found");
            }
            Console.ReadKey();

            void passData(string fn, string k)
            {
                //your connection string 
                string connString = @"Data Source = DESKTOP-DCEFN0U\SQLEXPRESS;Initial Catalog=Assignment3;Integrated Security=True";

                //create instanace of database connection
                SqlConnection conn = new SqlConnection(connString);
                try
                {
                    Console.WriteLine("Openning Connection ...");

                    //open connection
                    conn.Open();

                    Console.WriteLine("Connection successful!");

                    StringBuilder strBuilder = new StringBuilder();
                    StringReader strReader = new StringReader("");

                    strBuilder.Append("INSERT INTO custList(CUS_ID,CUS_NAME) VALUES ");
                    strBuilder.Append($"(N'{k}',N'{fn}')");
                    

                    string sqlQuery = strBuilder.ToString();
                    using (SqlCommand command = new SqlCommand(sqlQuery, conn)) //pass SQL query created above and connection
                    {
                        command.ExecuteNonQuery(); //execute the Query
                        Console.WriteLine("Query Executed.");
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("Error: " + e.Message);
                }
            }

            // BinarySearch requires a sorted ArrayList.
            list.Sort();

            // Compare results of an iterative search with a binary search

            Console.Write("Enter a name to search: ");
            string str = Console.ReadLine();
            string searchStr = list.IterativeSearch(str);
            Console.WriteLine(searchStr);

            int index = list.BinarySearch(str, new SimpleStringComparer());
            Console.WriteLine("Binary search, item found at index:    {0}", index);
            Console.ReadKey();
        }

        public string IterativeSearch(object finditem)
        {
            string index = Convert.ToString(finditem);

            for (int i = 0; i < this.Count; i++)
            {
                if (finditem.Equals(this[i]))
                {
                    index = Convert.ToString(this[i]);
                    break;
                }
            }
            return index;
        }
        
    }
}
